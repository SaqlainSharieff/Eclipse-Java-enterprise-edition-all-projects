package com.cg.smms.exceptions;

public class InvalidItemException  extends Exception{

}

package com.cg.smms.exceptions;

public class OrderCancelException extends Exception {

}

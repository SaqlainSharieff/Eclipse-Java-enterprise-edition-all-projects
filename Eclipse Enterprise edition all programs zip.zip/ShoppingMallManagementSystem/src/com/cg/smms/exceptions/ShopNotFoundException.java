package com.cg.smms.exceptions;

public class ShopNotFoundException extends Exception{

}

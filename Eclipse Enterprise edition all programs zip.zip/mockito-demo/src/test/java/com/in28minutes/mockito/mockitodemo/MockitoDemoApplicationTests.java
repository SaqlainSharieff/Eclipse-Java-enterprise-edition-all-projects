package com.in28minutes.mockito.mockitodemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MockitoDemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}

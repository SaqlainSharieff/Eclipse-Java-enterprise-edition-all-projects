package oops;

public class FilePersistence extends Persistence {

	@Override
	public void persist() {
		System.out.println("Inside File Persistence");
	}

	
}

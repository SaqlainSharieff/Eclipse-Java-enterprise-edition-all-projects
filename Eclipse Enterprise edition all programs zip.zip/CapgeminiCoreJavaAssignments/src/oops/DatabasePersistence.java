package oops;

public class DatabasePersistence extends Persistence {

	@Override
	public void persist() {
		System.out.println("Inside Database persistence");
	}

	
}

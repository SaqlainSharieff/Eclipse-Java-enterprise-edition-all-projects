package oops;

public abstract class Persistence {

	public  abstract void persist();
}

package generics;

public class PairTest {

	public static void main(String[] args) {
		Pair<String> P=new Pair<>();
		
		P.setKey("1");
		P.setKey("Harry");
		P.setValue(null);
		//Map<String,Date> map=new HashMap<>();
		
		//Pair<> d=new Pair<>();
		

	}

}

package collectionassignments;

public class DobTest {

	public static void main(String[] args) {
		
		Dob d1=new Dob();

	}

}

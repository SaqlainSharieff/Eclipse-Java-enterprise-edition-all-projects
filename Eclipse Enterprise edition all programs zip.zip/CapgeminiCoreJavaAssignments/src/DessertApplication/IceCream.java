package DessertApplication;

public class IceCream extends DessertItem{

	@Override
	public void getCost() {
		// TODO Auto-generated method stub
		
	}

}

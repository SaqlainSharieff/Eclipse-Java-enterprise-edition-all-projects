package DessertApplication;

public class Cookies extends DessertItem {

	@Override
	public void getCost() {
		// TODO Auto-generated method stub
		
	}

}

package com.cg.ThirdQuestion;

public class BankTest {

	public static void main(String[] args) {
		

	}

}

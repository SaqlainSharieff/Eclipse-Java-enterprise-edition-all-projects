package com.cg.ThirdQuestion;

public class BankRepositioryImpl implements BankAccountRepository{

	public double getBalance(long accountId) {
		
		return 0;
	}

	
	public double updatebalance(long accountId, double newBalance) {
		
		return 0;
	}

}

package com.cg.SpringCore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreAssignmentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
